# Na górze importujemy nową funkcję 'render_template'
from flask import Flask, render_template, request, url_for, redirect
import sqlite3
from datetime import date
import pandas as pd 

app = Flask(__name__)

# Ta funkcja pomoże nam stworzyć "słowniki" z wyników z bazy danych,
# co ułatwi dostęp do danych w szablonie HTML.
def get_db_connection():
    conn = sqlite3.connect('budget.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    # --- NOWA CZĘŚĆ: ODCZYT WYBRANEGO OKRESU ---
    # Pobieramy rok i miesiąc z parametrów URL (np. /?rok=2025&miesiac=8)
    # Jeśli ich nie ma, używamy bieżącego roku i miesiąca jako domyślnych.
    try:
        selected_year = int(request.args.get('rok', date.today().year))
        selected_month = int(request.args.get('miesiac', date.today().month))
    except (ValueError, TypeError):
        selected_year = date.today().year
        selected_month = date.today().month
    # -------------------------------------------

    conn = get_db_connection()

    kategorie = conn.execute('SELECT * FROM kategorie ORDER BY nazwa').fetchall()

    # --- OBLICZENIA DO DASHBOARDU (teraz używają wybranych zmiennych) ---
    przychody_cursor = conn.execute(
        "SELECT SUM(kwota) FROM transakcje WHERE kwota > 0 AND strftime('%Y-%m', data) = ?",
        (f"{selected_year}-{selected_month:02d}",)
    ).fetchone()
    total_przychody = przychody_cursor[0] if przychody_cursor[0] is not None else 0

    wydatki_cursor = conn.execute(
        "SELECT SUM(kwota) FROM transakcje WHERE kwota < 0 AND strftime('%Y-%m', data) = ?",
        (f"{selected_year}-{selected_month:02d}",)
    ).fetchone()
    total_wydatki = wydatki_cursor[0] if wydatki_cursor[0] is not None else 0
    
    bilans = total_przychody + total_wydatki
    # -------------------------------------------------------------------

    # --- DANE DO WYKRESU (teraz też używają wybranych zmiennych) ---
    query = "SELECT kategoria, kwota FROM transakcje WHERE kwota < 0 AND strftime('%Y-%m', data) = ?"
    params = (f"{selected_year}-{selected_month:02d}",)
    df_wydatki = pd.read_sql_query(query, conn, params=params)

    if not df_wydatki.empty:
        df_wydatki['kwota'] = df_wydatki['kwota'].abs()
        wydatki_po_kategorii = df_wydatki.groupby('kategoria')['kwota'].sum().reset_index()
        chart_labels = wydatki_po_kategorii['kategoria'].tolist()
        chart_values = wydatki_po_kategorii['kwota'].tolist()
    else:
        chart_labels = []
        chart_values = []
    # -------------------------------------------------------------

    # --- LISTA TRANSAKCJI (teraz też używa wybranych zmiennych) ---
    transakcje = conn.execute(
        "SELECT * FROM transakcje WHERE strftime('%Y-%m', data) = ? ORDER BY data DESC, id DESC",
        (f"{selected_year}-{selected_month:02d}",)
    ).fetchall()
    # -------------------------------------------------------------
    
    conn.close()
    
    # Przekazujemy do szablonu wszystkie potrzebne dane, w tym te do formularza wyboru
    return render_template(
        'index.html', 
        transakcje=transakcje,
        total_przychody=total_przychody,
        total_wydatki=total_wydatki,
        bilans=bilans,
        chart_labels=chart_labels,
        chart_values=chart_values,
        selected_year=selected_year,     # <-- NOWE
        selected_month=selected_month,    # <-- NOWE
        kategorie=kategorie
    )

@app.route('/add', methods=['POST'])
def add_transaction():
    opis = request.form['opis']
    kwota = request.form['kwota']
    kategoria = request.form['kategoria']
    dzisiejsza_data = date.today()

    conn = get_db_connection()
    conn.execute(
        "INSERT INTO transakcje (opis, kwota, kategoria, data) VALUES (?, ?, ?, ?)",
        (opis, kwota, kategoria, dzisiejsza_data)
    )
    conn.commit()
    conn.close()

    return redirect(url_for('index'))

@app.route('/delete/<int:id>')
def delete_transaction(id):
    conn = get_db_connection()
    # Wykonujemy polecenie SQL, aby usunąć wiersz o konkretnym id
    conn.execute('DELETE FROM transakcje WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    # Po usunięciu przekierowujemy użytkownika z powrotem na stronę główną
    return redirect(url_for('index'))

@app.route('/edit/<int:id>')
def edit_transaction(id):
    conn = get_db_connection()
    # Pobieramy z bazy konkretną transakcję o podanym id
    transakcja = conn.execute('SELECT * FROM transakcje WHERE id = ?', (id,)).fetchone()
    conn.close()
    # Renderujemy nowy szablon 'edit.html', przekazując do niego dane tej transakcji
    return render_template('edit.html', transakcja=transakcja)

# --- NOWA FUNKCJA DO ZAPISYWANIA ZMIAN ---
@app.route('/update/<int:id>', methods=['POST'])
def update_transaction(id):
    # Pobieramy zaktualizowane dane z formularza
    opis = request.form['opis']
    kwota = request.form['kwota']
    kategoria = request.form['kategoria']

    conn = get_db_connection()
    # Wykonujemy polecenie SQL UPDATE, aby zaktualizować wiersz o konkretnym id
    conn.execute(
        'UPDATE transakcje SET opis = ?, kwota = ?, kategoria = ? WHERE id = ?',
        (opis, kwota, kategoria, id)
    )
    conn.commit()
    conn.close()
    # Po aktualizacji przekierowujemy użytkownika z powrotem na stronę główną
    return redirect(url_for('index'))

# Wyświetla stronę z listą kategorii i formularzem do dodawania nowych
@app.route('/kategorie')
def manage_categories():
    conn = get_db_connection()
    kategorie = conn.execute('SELECT * FROM kategorie ORDER BY nazwa').fetchall()
    conn.close()
    return render_template('kategorie.html', kategorie=kategorie)

# Obsługuje dodawanie nowej kategorii
@app.route('/kategorie/add', methods=['POST'])
def add_category():
    nazwa_kategorii = request.form['nazwa']
    if nazwa_kategorii:
        conn = get_db_connection()
        # Używamy 'OR IGNORE', aby uniknąć błędu przy próbie dodania istniejącej kategorii
        conn.execute('INSERT OR IGNORE INTO kategorie (nazwa) VALUES (?)', (nazwa_kategorii,))
        conn.commit()
        conn.close()
    return redirect(url_for('manage_categories'))

# Obsługuje usuwanie kategorii
@app.route('/kategorie/delete/<int:id>')
def delete_category(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM kategorie WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('manage_categories'))

# ----------------------------------------------------

@app.route('/majatek')
def net_worth_page():
    conn = get_db_connection()

    # Pobieramy aktywa i pasywa
    aktywa = conn.execute('SELECT * FROM aktywa').fetchall()
    pasywa = conn.execute('SELECT * FROM pasywa').fetchall()

    # Obliczamy sumy
    suma_aktywów = conn.execute('SELECT SUM(wartosc) FROM aktywa').fetchone()[0] or 0
    suma_pasywów = conn.execute('SELECT SUM(wartosc) FROM pasywa').fetchone()[0] or 0

    aktywa_płynne = conn.execute("SELECT SUM(wartosc) FROM aktywa WHERE typ = 'płynne'").fetchone()[0] or 0
    wartosc_nieruchomosci = conn.execute("SELECT SUM(wartosc) FROM aktywa WHERE typ = 'nieruchomość'").fetchone()[0] or 0

    conn.close()

    # Obliczamy majątek netto
    majatek_netto_calkowity = suma_aktywów - suma_pasywów
    majatek_netto_plynny = aktywa_płynne - suma_pasywów

    return render_template(
        'majatek.html',
        aktywa=aktywa,
        pasywa=pasywa,
        majatek_netto_plynny=majatek_netto_plynny,
        wartosc_nieruchomosci=wartosc_nieruchomosci,
        majatek_netto_calkowity=majatek_netto_calkowity,
        chart_labels=[],
        chart_values=[]
    )
# ------------------------------------------------

@app.route('/majatek/add_asset', methods=['POST'])
def add_asset():
    nazwa = request.form['nazwa']
    wartosc = request.form['wartosc']
    typ = request.form['typ']

    if nazwa and wartosc and typ:
        conn = get_db_connection()
        conn.execute('INSERT INTO aktywa (nazwa, wartosc, typ) VALUES (?, ?, ?)', (nazwa, wartosc, typ))
        conn.commit()
        conn.close()
    return redirect(url_for('net_worth_page'))

@app.route('/majatek/add_liability', methods=['POST'])
def add_liability():
    nazwa = request.form['nazwa']
    wartosc = request.form['wartosc']

    if nazwa and wartosc:
        conn = get_db_connection()
        conn.execute('INSERT INTO pasywa (nazwa, wartosc) VALUES (?, ?)', (nazwa, wartosc))
        conn.commit()
        conn.close()
    return redirect(url_for('net_worth_page'))

@app.route('/majatek/delete_asset/<int:id>')
def delete_asset(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM aktywa WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('net_worth_page'))

@app.route('/majatek/delete_liability/<int:id>')
def delete_liability(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM pasywa WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('net_worth_page'))

# ----------------------------------------------------

if __name__ == '__main__':
    app.run(debug=True)